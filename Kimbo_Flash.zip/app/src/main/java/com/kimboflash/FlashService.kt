package com.kimboflash

object FlashService {
    fun isBluetoothConnected(): Boolean {
        // TODO: actual Bluetooth connection detection
        return false
    }
    fun isUsbConnected(): Boolean {
        // TODO: actual USB connection detection
        return false
    }
    fun isWifiConnected(): Boolean {
        // TODO: actual Wi-Fi connection detection
        return false
    }
}
