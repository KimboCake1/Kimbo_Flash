package com.kimboflash;

import android.app.Activity;

public class MonitoringActivity extends Activity {
}
